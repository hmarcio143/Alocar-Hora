<?php

require_once("models/User.php");
require_once("models/Message.php");
require_once("templetes/header.php");
require_once("dao/UserDao.php");
require_once("globals.php");
require_once("bd.php");


?>




<main>

<h2>Tutorial do sistema</h2>
</main>