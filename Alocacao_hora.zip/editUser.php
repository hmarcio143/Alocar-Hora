<?php
require_once("globals.php");
require_once("./bd.php");
require_once("models/Message.php");
require_once("models/User.php"); 
require_once("dao/UserDao.php");
require_once("templetes/header.php");


$idUser = $_GET["id"];

$userDao = new UserDao($conn, $BASE_URL);
$userData = $userDao->verifyToken(true);

$message = new Message($BASE_URL);
$user = new User();


$userAll = [];
// $queryuser = "SELECT CONCAT(name,' ',lastname) from usuario";
$queryuser = "SELECT * from usuario WHERE id='$idUser'";
$usuarios = $conn->prepare($queryuser);
$usuarios->execute();
$userAll = $usuarios->fetch();

?>
<?php if($user->getProfile($userData) == 1):?>

<main class="main-container">
        <h1>Editar usuario</h1>
        <div class="form">
            <form method="post" action="processo_dados.php">
                <input type="hidden" name="type" value="updateUsuario">
                <input type="hidden" name="id" value="<?=$userAll['id']?>">
                
                <input type="text" name="name" value="<?= $userAll['name']?>">
                <input type="text" name="lastname" value="<?= $userAll['lastname']?>">
                <input type="email" name="email"  value="<?= $userAll['email']?>">
                <input type="text" name="password"  value="<?= $userAll['password']?>" >
                <input type="text" name="confirmPassword"  value="<?= $userAll['password']?>" >
                <div class="div-input">
                    <select name="departamento">
                        <option value="Contabilidade">Contabilidade</option>
                        <option value="Fiscal">Fiscal</option>
                        <option value="Financeiro">Financeiro</option>
                        <option value="Departamento Pessoal">Departamento Pessoal</option>
                        <option value="Legalização">Legalização</option>
                    </select>
                </div>
                <label>Perfil do usuario:</label>
                <select name="profile">
                    <option value="2">Padrão - usuario</opition>
                    <option value="1">Adiministrador</opition>
                    <option value="3">Funcionario DP</opition>
                </select>
                <input type="submit" value="Editar usuario">
                
            </form>

            <div class="div-userDelete">
            <a class="link-table" href="<?=$BASE_URL?>confirmDelete.php?id=<?=$userAll['id']?>">Deletar Usuario</a>
            </div>

          
           
        </div>
    </main>

    <?php else:?>
        <?php $message->setMessage("Você não tem permissão para acessar essa pagina!!","erro" ,"painel.php");?>
        

<?php require_once("templetes/footer.php") ?>
<?php endif; ?>