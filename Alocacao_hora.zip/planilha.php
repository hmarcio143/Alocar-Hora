<?php
 require_once("templetes/header.php"); 
 require_once("models/User.php"); 
 require_once("dao/userDao.php"); 
 require_once("bd.php");


?>


