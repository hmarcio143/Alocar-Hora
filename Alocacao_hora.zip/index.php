
<?php
    require_once("globals.php");
?>

<head>
    <link rel="stylesheet" href="<?=$BASE_URL?>css/index.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
</head>

    <main class="main-container">
        <h1>Faça o Login para fazer o Lançamento</h1>
        <div class="form">
            <form method="post" action="login_process.php">
                <input type="hidden" name="type" value="create">
                <input type="email" name="email" placeholder="Digite seu E-mail" required>
                <input type="password" name="password" placeholder="digite sua senha" required>
                <input type="submit" value="entrar">
            </form>
        </div>

    </main>

